/**
 */
package org.softlang.megal;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Query Entry</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.softlang.megal.MegalPackage#getQueryEntry()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface QueryEntry extends EObject
{
} // QueryEntry
