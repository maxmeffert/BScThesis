/**
 */
package org.softlang.megal;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Declaration</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.softlang.megal.MegalPackage#getMegalDeclaration()
 * @model abstract="true"
 * @generated
 */
public interface MegalDeclaration extends MegalElement
{
} // MegalDeclaration
