package org.softlang.megal.browsing.dtos;

public class AbstractDto {

}
