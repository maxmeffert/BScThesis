package org.softlang.megal.browsing.util;

import org.eclipse.ui.part.WorkbenchPart;

public class WorkbenchInfo {
	
	private WorkbenchPart wbPart;
	
	public WorkbenchInfo(WorkbenchPart wbParth) {
		this.wbPart = wbPart;
	}
	
}
