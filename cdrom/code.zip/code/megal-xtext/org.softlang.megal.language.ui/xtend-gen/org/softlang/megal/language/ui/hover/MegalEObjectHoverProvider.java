package org.softlang.megal.language.ui.hover;

import com.google.common.base.Objects;
import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.ui.editor.hover.html.DefaultEObjectHoverProvider;
import org.eclipse.xtext.ui.editor.hover.html.XtextElementLinks;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.Functions.Function2;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.MapExtensions;
import org.softlang.megal.MegalAnnotation;
import org.softlang.megal.MegalDeclaration;
import org.softlang.megal.MegalEntity;
import org.softlang.megal.MegalEntityType;
import org.softlang.megal.MegalFile;
import org.softlang.megal.MegalLink;
import org.softlang.megal.MegalPlugin;
import org.softlang.megal.MegalRelationshipType;
import org.softlang.megal.Selection;
import org.softlang.megal.fragmentprovider.Evaluator;
import org.softlang.megal.language.MegalReasoning;
import org.softlang.megal.mi2.Element;
import org.softlang.megal.mi2.Entity;
import org.softlang.megal.mi2.KB;
import org.softlang.megal.mi2.MegamodelResolver;
import org.softlang.megal.mi2.Queries;
import org.softlang.megal.mi2.Query;
import org.softlang.megal.mi2.Relationship;
import org.softlang.megal.mi2.RelationshipType;
import org.softlang.megal.mi2.api.Result;

@SuppressWarnings("all")
public class MegalEObjectHoverProvider extends DefaultEObjectHoverProvider {
  private final List<Class<MegalAnnotation>> unnamedHoverable = Collections.<Class<MegalAnnotation>>unmodifiableList(CollectionLiterals.<Class<MegalAnnotation>>newArrayList(MegalAnnotation.class));
  
  public String link(final EObject o) {
    String _xtrycatchfinallyexpression = null;
    try {
      XtextElementLinks _elementLinks = this.getElementLinks();
      _xtrycatchfinallyexpression = _elementLinks.createLink(o);
    } catch (final Throwable _t) {
      if (_t instanceof NullPointerException) {
        final NullPointerException e = (NullPointerException)_t;
        ILabelProvider _labelProvider = this.getLabelProvider();
        _xtrycatchfinallyexpression = _labelProvider.getText(o);
      } else {
        throw Exceptions.sneakyThrow(_t);
      }
    }
    return _xtrycatchfinallyexpression;
  }
  
  @Override
  protected boolean hasHover(final EObject o) {
    return (IterableExtensions.<Class<MegalAnnotation>>exists(this.unnamedHoverable, ((Function1<Class<MegalAnnotation>, Boolean>) (Class<MegalAnnotation> x) -> {
      return Boolean.valueOf(x.isInstance(o));
    })) || super.hasHover(o));
  }
  
  @Override
  protected String getFirstLine(final EObject object) {
    CharSequence _firstLineFor = this.firstLineFor(object);
    final CharSequence p = _firstLineFor;
    boolean _matched = false;
    if (Objects.equal(p, null)) {
      _matched=true;
      return super.getFirstLine(object);
    }
    return p.toString();
  }
  
  @Override
  protected String getDocumentation(final EObject object) {
    CharSequence _documentationFor = this.documentationFor(object);
    final CharSequence p = _documentationFor;
    boolean _matched = false;
    if (Objects.equal(p, null)) {
      _matched=true;
      return super.getDocumentation(object);
    }
    return p.toString();
  }
  
  protected CharSequence _firstLineFor(final EObject it) {
    return null;
  }
  
  protected CharSequence _documentationFor(final EObject it) {
    return null;
  }
  
  protected CharSequence _firstLineFor(final MegalAnnotation it) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Annotation, ");
    {
      Selection _selection = it.getSelection();
      boolean _isStatic = Queries.isStatic(_selection);
      if (_isStatic) {
        _builder.append("static");
      } else {
        _builder.append("dynamic");
      }
    }
    _builder.append(" value");
    return _builder.toString();
  }
  
  protected CharSequence _documentationFor(final MegalAnnotation it) {
    Selection _selection = it.getSelection();
    final Query query = Queries.convert(_selection);
    int _symbols = query.symbols();
    boolean _greaterThan = (_symbols > 0);
    if (_greaterThan) {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("Parameterized, ");
      int _symbols_1 = query.symbols();
      _builder.append(_symbols_1, "");
      _builder.append(" entries.");
      return _builder.toString();
    }
    Set<List<Object>> _switchResult = null;
    EObject _eContainer = it.eContainer();
    final EObject item = _eContainer;
    boolean _matched = false;
    if (item instanceof MegalFile) {
      _matched=true;
      KB _kB = MegalReasoning.getKB(((MegalFile)item));
      _switchResult = query.execute(_kB);
    }
    if (!_matched) {
      if (item instanceof MegalDeclaration) {
        _matched=true;
        KB _kB = MegalReasoning.getKB(((MegalDeclaration)item));
        _switchResult = query.execute(_kB);
      }
    }
    final Set<List<Object>> rows = _switchResult;
    StringConcatenation _builder_1 = new StringConcatenation();
    {
      for(final List<Object> row : rows) {
        String _join = IterableExtensions.join(row, ", ");
        _builder_1.append(_join, "");
        _builder_1.append("<br/>");
      }
    }
    return _builder_1.toString();
  }
  
  protected CharSequence _firstLineFor(final MegalEntity it) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<b>");
    String _name = it.getName();
    _builder.append(_name, "");
    _builder.append("</b> : ");
    MegalEntityType _type = it.getType();
    String _link = this.link(_type);
    _builder.append(_link, "");
    return _builder.toString();
  }
  
  public CharSequence outputTraces(final Result result, final Element element) {
    CharSequence _xblockexpression = null;
    {
      Map<Element, Element> _origin = result.getOrigin();
      final Function2<Element, Element, Boolean> _function = (Element a, Element b) -> {
        return Boolean.valueOf(Objects.equal(b, element));
      };
      Map<Element, Element> _filter = MapExtensions.<Element, Element>filter(_origin, _function);
      final Set<Element> r = _filter.keySet();
      CharSequence _xifexpression = null;
      boolean _isEmpty = r.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        StringConcatenation _builder = new StringConcatenation();
        _builder.append("<p>Elements derived from this");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("<ul>");
        _builder.newLine();
        {
          Iterable<Element> _take = IterableExtensions.<Element>take(r, 15);
          for(final Element f : _take) {
            _builder.append("\t\t");
            _builder.append("<li>");
            _builder.append(f, "\t\t");
            _builder.append("</li>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          Iterable<Element> _drop = IterableExtensions.<Element>drop(r, 15);
          boolean _isEmpty_1 = IterableExtensions.isEmpty(_drop);
          boolean _not_1 = (!_isEmpty_1);
          if (_not_1) {
            _builder.append("\t\t");
            _builder.append("<li>...</li>");
            _builder.newLine();
          }
        }
        _builder.append("\t");
        _builder.append("</ul>");
        _builder.newLine();
        _builder.append("</p>");
        _builder.newLine();
        _xifexpression = _builder;
      } else {
        StringConcatenation _builder_1 = new StringConcatenation();
        _xifexpression = _builder_1;
      }
      _xblockexpression = _xifexpression;
    }
    return _xblockexpression;
  }
  
  /**
   * Calculates the documentation for an EObject or null if no documentation
   */
  protected CharSequence _documentationFor(final MegalEntity it) {
    final Result exe = MegalReasoning.getLocalResult(it);
    final MegamodelResolver res = MegamodelResolver.transitive(it);
    KB _output = exe.getOutput();
    String _name = it.getName();
    final Entity rep = _output.getEntity(_name);
    final Set<Relationship> incoming = rep.incoming();
    final Set<Relationship> outgoing = rep.outgoing();
    StringConcatenation _builder = new StringConcatenation();
    String _documentation = super.getDocumentation(it);
    _builder.append(_documentation, "");
    _builder.newLineIfNotEmpty();
    _builder.append("<p>");
    _builder.newLine();
    {
      boolean _hasBinding = rep.hasBinding();
      if (_hasBinding) {
        _builder.append("Bound to <a href=\"");
        Object _binding = rep.getBinding();
        _builder.append(_binding, "");
        _builder.append("\">");
        Object _binding_1 = rep.getBinding();
        _builder.append(_binding_1, "");
        _builder.append("</a>");
        _builder.newLineIfNotEmpty();
      } else {
        _builder.append("Not bound after execution.");
        _builder.newLine();
      }
    }
    _builder.append("</p>");
    _builder.newLine();
    CharSequence _outputTraces = this.outputTraces(exe, rep);
    _builder.append(_outputTraces, "");
    _builder.newLineIfNotEmpty();
    {
      if (((!incoming.isEmpty()) || (!outgoing.isEmpty()))) {
        _builder.append("<p>Relationships in defined document: <ul>");
        _builder.newLine();
        {
          for(final Relationship in : incoming) {
            _builder.append("\t");
            _builder.append("<li>");
            Entity _left = in.getLeft();
            MegalEntity _resolve = res.resolve(_left);
            String _link = this.link(_resolve);
            _builder.append(_link, "\t");
            _builder.append(" ");
            RelationshipType _type = in.getType();
            MegalRelationshipType _resolve_1 = res.resolve(_type);
            String _link_1 = this.link(_resolve_1);
            _builder.append(_link_1, "\t");
            _builder.append(" <b>");
            String _name_1 = it.getName();
            _builder.append(_name_1, "\t");
            _builder.append("</b></li>");
            _builder.newLineIfNotEmpty();
          }
        }
        {
          for(final Relationship out : outgoing) {
            _builder.append("\t");
            _builder.append("<li><b>");
            String _name_2 = it.getName();
            _builder.append(_name_2, "\t");
            _builder.append("</b> ");
            RelationshipType _type_1 = out.getType();
            MegalRelationshipType _resolve_2 = res.resolve(_type_1);
            String _link_2 = this.link(_resolve_2);
            _builder.append(_link_2, "\t");
            _builder.append(" ");
            Entity _right = out.getRight();
            MegalEntity _resolve_3 = res.resolve(_right);
            String _link_3 = this.link(_resolve_3);
            _builder.append(_link_3, "\t");
            _builder.append("</li>");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append("\t");
        _builder.append("</ul></p>");
        _builder.newLine();
      }
    }
    _builder.newLine();
    return _builder.toString();
  }
  
  protected CharSequence _firstLineFor(final MegalEntityType it) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<b>");
    String _name = it.getName();
    _builder.append(_name, "");
    _builder.append("</b> ");
    {
      MegalEntityType _supertype = it.getSupertype();
      boolean _notEquals = (!Objects.equal(_supertype, null));
      if (_notEquals) {
        _builder.append("  &lt; ");
        MegalEntityType _supertype_1 = it.getSupertype();
        String _link = this.link(_supertype_1);
        _builder.append(_link, "");
      }
    }
    return _builder;
  }
  
  protected CharSequence _firstLineFor(final MegalRelationshipType it) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<b>");
    String _name = it.getName();
    _builder.append(_name, "");
    _builder.append("</b>");
    return _builder;
  }
  
  protected CharSequence _documentationFor(final MegalEntityType it) {
    StringConcatenation _builder = new StringConcatenation();
    String _documentation = super.getDocumentation(it);
    _builder.append(_documentation, "");
    return _builder;
  }
  
  protected CharSequence _documentationFor(final MegalRelationshipType relationshipType) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("xxxx");
    return _builder;
  }
  
  protected CharSequence _documentationFor(final MegalLink it) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("<ul>");
    {
      Evaluator _evaluator = MegalPlugin.getEvaluator();
      String _to = it.getTo();
      URI _create = URI.create(_to);
      List<Object> _evaluate = _evaluator.evaluate(_create);
      for(final Object n : _evaluate) {
        _builder.append("<li>");
        _builder.append(n, "");
        _builder.append("</li>");
      }
    }
    _builder.append("</ul>");
    return _builder;
  }
  
  public CharSequence firstLineFor(final EObject it) {
    if (it instanceof MegalEntity) {
      return _firstLineFor((MegalEntity)it);
    } else if (it instanceof MegalEntityType) {
      return _firstLineFor((MegalEntityType)it);
    } else if (it instanceof MegalRelationshipType) {
      return _firstLineFor((MegalRelationshipType)it);
    } else if (it instanceof MegalAnnotation) {
      return _firstLineFor((MegalAnnotation)it);
    } else if (it != null) {
      return _firstLineFor(it);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(it).toString());
    }
  }
  
  public CharSequence documentationFor(final EObject it) {
    if (it instanceof MegalEntity) {
      return _documentationFor((MegalEntity)it);
    } else if (it instanceof MegalEntityType) {
      return _documentationFor((MegalEntityType)it);
    } else if (it instanceof MegalRelationshipType) {
      return _documentationFor((MegalRelationshipType)it);
    } else if (it instanceof MegalLink) {
      return _documentationFor((MegalLink)it);
    } else if (it instanceof MegalAnnotation) {
      return _documentationFor((MegalAnnotation)it);
    } else if (it != null) {
      return _documentationFor(it);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(it).toString());
    }
  }
}
