package org.softlang.megal.language.ui.highlighting;

import org.eclipse.swt.SWT;
import org.eclipse.xtext.ui.editor.syntaxcoloring.DefaultHighlightingConfiguration;
import org.eclipse.xtext.ui.editor.syntaxcoloring.IHighlightingConfigurationAcceptor;
import org.eclipse.xtext.ui.editor.utils.TextStyle;
import org.eclipse.xtext.xbase.lib.ObjectExtensions;
import org.eclipse.xtext.xbase.lib.Procedures.Procedure1;

@SuppressWarnings("all")
public class MegalHighlightingConfiguration extends DefaultHighlightingConfiguration {
  public final static String ENTITY_ID = "entity";
  
  public final static String RELATIONSHIP_ID = "relationship";
  
  public final static String ENTITY_TYPE_ID = "entity_type";
  
  public final static String RELATIONSHIP_TYPE_ID = "relationship_type";
  
  @Override
  public void configure(final IHighlightingConfigurationAcceptor acceptor) {
    super.configure(acceptor);
    TextStyle _entityTextStyle = this.entityTextStyle();
    acceptor.acceptDefaultHighlighting(MegalHighlightingConfiguration.ENTITY_ID, "Entity", _entityTextStyle);
    TextStyle _entityTypeTextStyle = this.entityTypeTextStyle();
    acceptor.acceptDefaultHighlighting(MegalHighlightingConfiguration.ENTITY_TYPE_ID, "Entity type", _entityTypeTextStyle);
    TextStyle _relationshipTextStyle = this.relationshipTextStyle();
    acceptor.acceptDefaultHighlighting(MegalHighlightingConfiguration.RELATIONSHIP_ID, "Relationship", _relationshipTextStyle);
    TextStyle _relationshipTypeTextStyle = this.relationshipTypeTextStyle();
    acceptor.acceptDefaultHighlighting(MegalHighlightingConfiguration.RELATIONSHIP_TYPE_ID, "Relationship type", _relationshipTypeTextStyle);
  }
  
  public TextStyle entityTextStyle() {
    TextStyle _defaultTextStyle = this.defaultTextStyle();
    TextStyle _copy = _defaultTextStyle.copy();
    final Procedure1<TextStyle> _function = (TextStyle it) -> {
    };
    return ObjectExtensions.<TextStyle>operator_doubleArrow(_copy, _function);
  }
  
  public TextStyle relationshipTextStyle() {
    TextStyle _defaultTextStyle = this.defaultTextStyle();
    TextStyle _copy = _defaultTextStyle.copy();
    final Procedure1<TextStyle> _function = (TextStyle it) -> {
      it.setStyle(SWT.ITALIC);
    };
    return ObjectExtensions.<TextStyle>operator_doubleArrow(_copy, _function);
  }
  
  public TextStyle entityTypeTextStyle() {
    TextStyle _defaultTextStyle = this.defaultTextStyle();
    TextStyle _copy = _defaultTextStyle.copy();
    final Procedure1<TextStyle> _function = (TextStyle it) -> {
    };
    return ObjectExtensions.<TextStyle>operator_doubleArrow(_copy, _function);
  }
  
  public TextStyle relationshipTypeTextStyle() {
    TextStyle _defaultTextStyle = this.defaultTextStyle();
    TextStyle _copy = _defaultTextStyle.copy();
    final Procedure1<TextStyle> _function = (TextStyle it) -> {
      it.setStyle(SWT.ITALIC);
    };
    return ObjectExtensions.<TextStyle>operator_doubleArrow(_copy, _function);
  }
}
