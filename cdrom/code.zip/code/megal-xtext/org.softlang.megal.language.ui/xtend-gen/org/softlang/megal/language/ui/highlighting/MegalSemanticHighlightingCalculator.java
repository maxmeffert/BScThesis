package org.softlang.megal.language.ui.highlighting;

import com.google.common.base.Objects;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.xtext.ui.editor.syntaxcoloring.DefaultSemanticHighlightingCalculator;
import org.eclipse.xtext.ui.editor.syntaxcoloring.IHighlightedPositionAcceptor;
import org.eclipse.xtext.xbase.lib.CollectionLiterals;
import org.eclipse.xtext.xbase.lib.Pair;
import org.softlang.megal.MegalEntity;
import org.softlang.megal.MegalEntityType;
import org.softlang.megal.MegalPackage;
import org.softlang.megal.MegalRelationship;
import org.softlang.megal.MegalRelationshipType;
import org.softlang.megal.language.ui.highlighting.MegalHighlightingConfiguration;

@SuppressWarnings("all")
public class MegalSemanticHighlightingCalculator extends DefaultSemanticHighlightingCalculator {
  @Override
  protected boolean highlightElement(final EObject object, final IHighlightedPositionAcceptor acceptor) {
    List<? extends Pair<? extends EStructuralFeature, String>> _stylesFor = this.stylesFor(object);
    final List<? extends Pair<? extends EStructuralFeature, String>> p = _stylesFor;
    boolean _matched = false;
    if (Objects.equal(p, null)) {
      _matched=true;
      return super.highlightElement(object, acceptor);
    }
    {
      for (final Pair<? extends EStructuralFeature, String> k : p) {
        EStructuralFeature _key = k.getKey();
        String _value = k.getValue();
        this.highlightFeature(acceptor, object, _key, _value);
      }
      return true;
    }
  }
  
  /**
   * Calculates the style mapping for an EObject or null if no style mapping
   */
  protected List<? extends Pair<? extends EStructuralFeature, String>> _stylesFor(final EObject object) {
    return null;
  }
  
  protected List<? extends Pair<? extends EStructuralFeature, String>> _stylesFor(final MegalEntity object) {
    Pair<EAttribute, String> _mappedTo = Pair.<EAttribute, String>of(MegalPackage.Literals.MEGAL_NAMED__NAME, MegalHighlightingConfiguration.ENTITY_ID);
    return Collections.<Pair<EAttribute, String>>unmodifiableList(CollectionLiterals.<Pair<EAttribute, String>>newArrayList(_mappedTo));
  }
  
  protected List<? extends Pair<? extends EStructuralFeature, String>> _stylesFor(final MegalEntityType object) {
    Pair<EAttribute, String> _mappedTo = Pair.<EAttribute, String>of(MegalPackage.Literals.MEGAL_NAMED__NAME, MegalHighlightingConfiguration.ENTITY_TYPE_ID);
    return Collections.<Pair<EAttribute, String>>unmodifiableList(CollectionLiterals.<Pair<EAttribute, String>>newArrayList(_mappedTo));
  }
  
  protected List<? extends Pair<? extends EStructuralFeature, String>> _stylesFor(final MegalRelationship object) {
    Pair<EReference, String> _mappedTo = Pair.<EReference, String>of(MegalPackage.Literals.MEGAL_RELATIONSHIP__TYPE, MegalHighlightingConfiguration.RELATIONSHIP_ID);
    return Collections.<Pair<EReference, String>>unmodifiableList(CollectionLiterals.<Pair<EReference, String>>newArrayList(_mappedTo));
  }
  
  protected List<? extends Pair<? extends EStructuralFeature, String>> _stylesFor(final MegalRelationshipType object) {
    Pair<EAttribute, String> _mappedTo = Pair.<EAttribute, String>of(MegalPackage.Literals.MEGAL_NAMED__NAME, MegalHighlightingConfiguration.RELATIONSHIP_TYPE_ID);
    return Collections.<Pair<EAttribute, String>>unmodifiableList(CollectionLiterals.<Pair<EAttribute, String>>newArrayList(_mappedTo));
  }
  
  public List<? extends Pair<? extends EStructuralFeature, String>> stylesFor(final EObject object) {
    if (object instanceof MegalEntity) {
      return _stylesFor((MegalEntity)object);
    } else if (object instanceof MegalEntityType) {
      return _stylesFor((MegalEntityType)object);
    } else if (object instanceof MegalRelationshipType) {
      return _stylesFor((MegalRelationshipType)object);
    } else if (object instanceof MegalRelationship) {
      return _stylesFor((MegalRelationship)object);
    } else if (object != null) {
      return _stylesFor(object);
    } else {
      throw new IllegalArgumentException("Unhandled parameter types: " +
        Arrays.<Object>asList(object).toString());
    }
  }
}
