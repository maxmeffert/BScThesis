package org.softlang.megal.language.ui.highlighting;

import org.eclipse.xtext.ui.editor.syntaxcoloring.DefaultAntlrTokenToAttributeIdMapper;
import org.eclipse.xtext.ui.editor.syntaxcoloring.DefaultHighlightingConfiguration;

@SuppressWarnings("all")
public class MegalAntlrTokenToAttributeIdMapper extends DefaultAntlrTokenToAttributeIdMapper {
  private final static String COMMENT_RULE = "RULE_COMMENT";
  
  @Override
  protected String calculateId(final String tokenName, final int tokenType) {
    String _switchResult = null;
    switch (tokenName) {
      case MegalAntlrTokenToAttributeIdMapper.COMMENT_RULE:
        _switchResult = DefaultHighlightingConfiguration.COMMENT_ID;
        break;
      default:
        _switchResult = super.calculateId(tokenName, tokenType);
        break;
    }
    return _switchResult;
  }
}
