package as.ex;

public class Sasa {
	public int foo;
	public int bar;
}
