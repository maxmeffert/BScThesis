This is an implementation of the 101companies System.

Headline: Object/XML mapping for Java and XSD with JAXB

Documentation: http://101companies.org/wiki/Contribution:jaxbComposition

Build instructions: https://github.com/101companies/101simplejava