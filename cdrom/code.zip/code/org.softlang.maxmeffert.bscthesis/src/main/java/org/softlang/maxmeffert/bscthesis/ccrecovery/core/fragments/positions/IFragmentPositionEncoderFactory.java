package org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.positions;

public interface IFragmentPositionEncoderFactory {
    IFragmentPositionEncoder newFragmentPositionEncoder();
}
