package org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.analyzers;

public interface IFragmentAnalyzerFactory {
    IFragmentAnalyzer newFragmentAnalyzer();
}
