package org.softlang.maxmeffert.bscthesis.ccrecovery.core.parsers;

public class ParserException extends Exception {
    public ParserException(String message) {
        super(message);
    }
}
