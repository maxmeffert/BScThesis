package org.softlang.maxmeffert.bscthesis.ccrecovery.core.antlr;

import org.antlr.v4.runtime.ParserRuleContext;

public interface IAntlrUtilities {
    String getOriginalText(ParserRuleContext parserRuleContext);
}
