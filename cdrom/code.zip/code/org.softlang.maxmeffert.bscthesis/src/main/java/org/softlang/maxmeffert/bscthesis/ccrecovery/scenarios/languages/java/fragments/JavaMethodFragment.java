package org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.java.fragments;


public class JavaMethodFragment extends TypedJavaFragment {
}
