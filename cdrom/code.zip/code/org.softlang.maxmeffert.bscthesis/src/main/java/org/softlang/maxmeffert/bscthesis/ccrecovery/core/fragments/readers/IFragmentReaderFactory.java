package org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.readers;

public interface IFragmentReaderFactory {
    IFragmentReader newFragmentReader();
}
