package org.softlang.maxmeffert.bscthesis.ccrecovery.core.antlr;

public interface IAntlrParseTreeErrorNodeListenerFactory {
    IAntlrParseTreeErrorNodeListener newErrorNodeListener();
}
