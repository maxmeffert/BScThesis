package org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.xml.fragments;

public class XmlAttributeFragment extends NamedXmlFragment {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
