package org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.xml.fragments;

import org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.BaseFragment;

public class XmlFragment extends BaseFragment {

}
