package org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.uris;

public interface IFragmentUriConverterFactory {
    IFragmentUriConverter newFragmentUriConverter();
}
