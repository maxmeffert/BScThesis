package org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.java.fragments;

import org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.BaseFragment;

public abstract class JavaFragment extends BaseFragment {

}
