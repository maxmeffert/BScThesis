package org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.sql.fragments;

import org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.BaseFragment;

public class SqlColumnFragment extends BaseFragment {

    private String columnName = "";

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }
}
