package org.softlang.maxmeffert.bscthesis.ccrecovery.core.fragments.kbs;

public interface IFragmentKBBuilderFactory {
    IFragmentKBBuilder newFragmentKBBuilder();
}
