package org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.java.fragments;

public class JavaFieldFragment extends TypedJavaFragment {
}
