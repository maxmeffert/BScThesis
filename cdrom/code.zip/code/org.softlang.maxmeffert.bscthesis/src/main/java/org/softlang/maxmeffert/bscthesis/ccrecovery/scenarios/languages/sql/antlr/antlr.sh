java -jar antlr.jar Sql.g4  -package 'org.softlang.maxmeffert.bscthesis.ccrecovery.scenarios.languages.sql.antlr'
